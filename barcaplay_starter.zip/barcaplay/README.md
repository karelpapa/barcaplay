# BarçaPlay — prototipo gratuito

Web adaptable e instalable como PWA con calendario de demostración, filtros, favoritos guardados en el dispositivo y enlaces a páginas oficiales.

## Importante
No incluye ni retransmite partidos en directo. Los derechos dependen del país, encuentro y proveedor. Los datos que aparecen en las tarjetas son de demostración, no un calendario actualizado.

## Publicación sencilla
1. Sube todos los archivos de esta carpeta a un repositorio GitHub.
2. En GitHub, entra en Settings → Pages.
3. En Build and deployment, selecciona Deploy from a branch, elige `main` y `/ (root)`, y guarda.
4. Cuando GitHub Pages publique la web, abre el enlace en Chrome de Android.
5. En Chrome toca ⋮ → Instalar aplicación o Añadir a pantalla de inicio.

Los servicios gratuitos tienen límites y pueden cambiar. Para mostrar fixture/resultados actuales hace falta conectar una fuente de datos fiable; para retransmitir, fuentes autorizadas.
